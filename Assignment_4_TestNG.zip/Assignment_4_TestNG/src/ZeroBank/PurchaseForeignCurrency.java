
package ZeroBank;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class PurchaseForeignCurrency {
	
	public WebDriver driver;
	
	
	@BeforeSuite(groups = {"Regression" })
	public void setUp() {
		 System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDriver\\chromedriver.exe");
		 WebDriver driver = new ChromeDriver(); 
         driver.manage().window().maximize();
         driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
         driver.get("http://zero.webappsecurity.com/");
 		assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards");
	}
         
    BeforeSuite(groups = { "Smoke" })   
    public void setUp() {
		 System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDriver\\chromedriver.exe");
		 WebDriver driver = new ChromeDriver(); 
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("http://zero.webappsecurity.com/");
		assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards");
	}
    
	
	@Test
	public void LogIn() {
		driver.get("http://zero.webappsecurity.com/");
		assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards");
        
        
        driver.findElement(By.id("signin_button")).click();
     
        driver.findElement(By.name("user_login")).sendKeys("username");
     
        driver.findElement(By.cssSelector("[type='password']")).sendKeys("password");
     
        driver.findElement(By.xpath("//input[@name='submit']")).click();
     
        driver.findElement(By.xpath("//button[@id='details-button']")).click();
        driver.findElement(By.linkText("Proceed to zero.webappsecurity.com (unsafe)")).click();
        
        assertEquals(driver.getTitle(), "Zero - Account Summary");
	}
     @Test(priority = 2, enabled = fales, groups = { "Regression" }) 
     public void LogIn() {
 		driver.get("http://zero.webappsecurity.com/");
 		assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards");
         
         
         driver.findElement(By.id("signin_button")).click();
      
         driver.findElement(By.name("user_login")).sendKeys("username");
      
         driver.findElement(By.cssSelector("[type='password']")).sendKeys("password");
      
         driver.findElement(By.xpath("//input[@name='submit']")).click();
      
         driver.findElement(By.xpath("//button[@id='details-button']")).click();
         driver.findElement(By.linkText("Proceed to zero.webappsecurity.com (unsafe)")).click();
         
         assertEquals(driver.getTitle(), "Zero - Account Summary");
     
     }
     @Test(priority = 2, enabled = true, groups = { "Regression" }) 
     public void LogIn() {
 		driver.get("http://zero.webappsecurity.com/");
 		assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards");
         
         
         driver.findElement(By.id("signin_button")).click();
      
         driver.findElement(By.name("user_login")).sendKeys("username");
      
         driver.findElement(By.cssSelector("[type='password']")).sendKeys("password");
      
         driver.findElement(By.xpath("//input[@name='submit']")).click();
      
         driver.findElement(By.xpath("//button[@id='details-button']")).click();
         driver.findElement(By.linkText("Proceed to zero.webappsecurity.com (unsafe)")).click();
         
         assertEquals(driver.getTitle(), "Zero - Account Summary");
     
     }
     @Test(priority = 3, enabled = true, groups = { "Regression" }) 
     public void PayBills() {
      //By linktext
        driver.findElement(By.linkText("Pay Bills")).click();
        
        driver.findElement(By.xpath("//a[contains(text(),'Purchase Foreign Currency')]")).click();
       // Thread.sleep(10000);
        driver.findElement(By.cssSelector("#purchase_cash")).click();
        
        Alert zeroAlert = driver.switchTo().alert();
        String alertText = zeroAlert.getText();
        System.out.println("The text on the ZeroBank Alert is - ' "+ alertText +"'");
      
        zeroAlert.accept();
     }
        @Test(priority = 1, enabled = true, groups = { "smoke" })
    	public static void PurchaseForeignCurrency() {
        driver.findElement(By.xpath("//a[contains(text(),'Transfer Funds')]")).click();
        driver.findElement(By.xpath("//input[@id='tf_amount']")).sendKeys("1000");
        driver.findElement(By.xpath("//input[@id='tf_description']")).sendKeys("Employee");
        driver.findElement(By.xpath("//button[@id='btn_submit']")).click();
        driver.findElement(By.xpath("//button[@id='btn_submit']")).click();
        }  
   @AfterTest
    public void LogOut() {
        	 driver.findElement(By.xpath("(//a[@class='dropdown-toggle'])[2]")).click();
     		 driver.findElement(By.linkText("Logout")).click();
     		
     		 //close browser
             driver.close();
            
             // kill/quit driver
             driver.quit();
        	
        }
         
	}
	

}
